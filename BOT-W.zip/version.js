import { fetchLatestBaileysVersion } from "@whiskeysockets/baileys";

async function obtenerVersion() {
  try {
    const result = await fetchLatestBaileysVersion();
    console.log("Resultado de fetchLatestBaileysVersion:", result);

    // Si es un arreglo (array), lo desestructuramos
    if (Array.isArray(result)) {
      const [version, isLatest] = result;
      console.log("Versión actual de WhatsApp Web:", version);
      console.log("¿Es la última versión?:", isLatest);
    } else {
      // Si no es array, imprimimos tal cual
      console.log("fetchLatestBaileysVersion no devolvió un arreglo:", result);
    }
  } catch (error) {
    console.error("Error al obtener la versión:", error);
  }
}

obtenerVersion();
