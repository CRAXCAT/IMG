import { exec } from 'child_process';

// Importa la función verificarRolUsuario desde tu módulo de conexión
import { verificarRolUsuario } from "../conexion.js";

export default {
  name: "pass",
  description: "Cambia la contraseña de una VPS.",
  alias: ["pass"],
  use: "!pass 'IP|USER|PASS|NEW_PASS'",

  run: async (socket, msg, args) => {
    // Verificar el rol del usuario
    const sender = msg.messages[0]?.key?.remoteJid;
    verificarRolUsuario(sender, async (err, rol) => {
      if (err) {
        console.error(err);
        socket.sendMessage(sender, {
          text: "Error al verificar el rol del usuario.",
        });
        return;
      }
      
      // Si el rol no es el adecuado, enviar un mensaje de error y salir
      if (rol !== "usuario" && rol !== "admin") {
        socket.sendMessage(sender, {
          text: "No tienes permiso para ejecutar este comando.",
        });
        return;
      }

      // Verificar si se proporcionaron los argumentos esperados
      if (args.length < 1) {
        socket.sendMessage(sender, {
          text: "Faltan argumentos. Usa el comando de la forma: !pass 'IP|USER|PASS|NEW_PASS'",
        });
        return;
      }

      const input = args.join(" "); // Unir los argumentos en una sola cadena
      const [ip, usuario, password, newPass] = input.split("|");

      // Verificar si todos los argumentos necesarios están presentes
      if (!ip || !usuario || !password || !newPass) {
        socket.sendMessage(sender, {
          text: "Faltan argumentos. Usa el comando de la forma: !pass 'IP|USER|PASS|NEW_PASS'",
        });
        return;
      }

      // Comando para cambiar la contraseña en la VPS
      const command = `sshpass -p "${password}" ssh ${usuario}@${ip} 'echo "${usuario}:${newPass}" | sudo chpasswd'`;

      // Ejecutar el comando para cambiar la contraseña
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error al cambiar la contraseña: ${error.message}`);
          socket.sendMessage(sender, {
            text: `Error al cambiar la contraseña en la VPS. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        if (stderr) {
          console.error(`Error en la salida estándar del comando: ${stderr}`);
          socket.sendMessage(sender, {
            text: `Error al cambiar la contraseña en la VPS. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        console.log(`Contraseña cambiada correctamente en la VPS: ${stdout}`);
        
        // Enviar mensaje de éxito al usuario
        socket.sendMessage(sender, {
          text: `La contraseña se ha cambiado correctamente en la VPS.`,
        });
      });
    });
  },
};
