import { exec } from "child_process";

// Importa la función verificarRolUsuario desde tu módulo de conexión
import { verificarRolUsuario } from "../conexion.js";

export default {
  name: "keygen",
  description: "Ejecuta el comando 'ls'.",
  alias: ["keygen"],
  use: "!keygen",

  run: async (socket, msg, args) => {
    // Verificar el rol del usuario
    const sender = msg.messages[0]?.key?.remoteJid;
    verificarRolUsuario(sender, async (err, rol) => {
      if (err) {
        console.error(err);
        socket.sendMessage(sender, {
          text: "Error al verificar el rol del usuario.",
        });
        return;
      }
      
      // Si el rol no es el adecuado, enviar un mensaje de error y salir
      if (rol !== "usuario" && rol !== "admin") {
        socket.sendMessage(sender, {
          text: "No tienes permiso para ejecutar este comando.",
        });
        return;
      }

      // Ejecutar el comando ls
      exec(`/root/BOT_W/key.sh`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error al ejecutar el comando ls: ${error.message}`);
          socket.sendMessage(sender, {
            text: `Error al ejecutar el comando ls. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        if (stderr) {
          console.error(`Error en la salida estándar del comando ls: ${stderr}`);
          socket.sendMessage(sender, {
            text: `Error al ejecutar el comando ls. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        console.log(`Salida estándar del comando ls: ${stdout}`);
        let aswe3 = `
🆂🅲🆁🅸🅿️🆃 🅽🅸🆇🅾️🅽🅼🅲 
═══════════ ◖◍◗ ═══════════
🔑 KEY GENERADA V9.9N🔑
  👤Reseller: By @Nikobhyn
⏱️ Vence: En 2 Hrs o al Usarla
═══════════ ◖◍◗ ═══════════
◈💾 TOCA EL INSTALADOR ◈
wget https://raw.githubusercontent.com/; chmod 777 NIXON-MC; ./NIXON-MC
┈━═💫━━━•❪⊱⭐️⊰❫•━━━💫═━┈
◈🔑COPIAR LA KEY🔑◈
${stdout}
═══════════ ◖◍◗ ═══════════
☫ S.O Recomendado 📀Ubuntu 20 x64
☫Ubuntu 18,20 x64- Debian 7,8,9,10 x64
═══════════ ◖◍◗ ═══════════
©ঔৣ‌➳•སར×๑ས ༒۝•ʍc•🇵🇪®➋⓪➋④
█│║▌ ║││█║▌ │║║█║█│║▌ ║
𝓓𝓮𝓻𝓮𝓬𝓱𝓸𝓼 𝓡𝓮𝓼𝓮𝓻𝓿𝓪𝓭𝓸𝓼 𝓒𝓸𝓹𝔂𝓻𝓲𝓰𝓱𝓽 𝓝𝓲𝔁𝓸𝓷 𝓜𝓒 
═══════════ ◖◍◗ ═══════════ 
      `;
        // Enviar la salida del comando ls como respuesta al usuario a través del socket
        socket.sendMessage(sender, {
          text: aswe3,
        });
      });
    });
  },
};
