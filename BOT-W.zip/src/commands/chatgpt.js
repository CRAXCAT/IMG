import dotenv from "dotenv";
dotenv.config(); // Carga variables del archivo .env en process.env
//console.log("Clave API leída:", process.env.OPENAI_API_KEY); // <-- Aquí imprime la clave
import OpenAI from "openai";
import { verificarRolUsuario } from "../conexion.js";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default {
  name: "chatgpt",
  description: "Chat con ChatGPT",
  alias: ["cgpt"],
  use: "/chatgpt 'tu pregunta o mensaje'",

  run: async (socket, msg, args) => {
    const prompt = args.join(" ");
    const remoteJid = msg.messages[0].key.remoteJid;

    if (!prompt) {
      return socket.sendMessage(remoteJid, {
        text: "Por favor, escribe algo para que ChatGPT responda.",
      });
    }

    verificarRolUsuario(remoteJid, async (err, rol) => {
      if (err) {
        console.error("Error al verificar rol:", err);
        return socket.sendMessage(remoteJid, {
          text: "Error al verificar permisos. Intenta más tarde.",
        });
      }

      if (!rol || (rol !== "usuario" && rol !== "admin")) {
        return socket.sendMessage(remoteJid, {
          text: "No tienes permisos para usar este comando.",
        });
      }

      try {
        await socket.sendMessage(remoteJid, {
          react: { text: "⏳", key: msg.messages[0].key },
        });

        const completion = await openai.chat.completions.create({
          model: "gpt-4o-mini",
          messages: [{ role: "user", content: prompt }],
          max_tokens: 500,
          temperature: 0.7,
        });

        const response = completion.choices[0].message.content;

        await socket.sendMessage(remoteJid, {
          text: response,
        });

        socket.sendMessage(remoteJid, {
          react: { text: "✅", key: msg.messages[0].key },
        });
      } catch (error) {
        console.error(error);
        await socket.sendMessage(remoteJid, {
          text: "¡Ups! Hubo un error al procesar tu solicitud.",
        });
        socket.sendMessage(remoteJid, {
          react: { text: "❌", key: msg.messages[0].key },
        });
      }
    });
  },
};
