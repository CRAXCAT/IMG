import axios from "axios";

export default {
  name: "ehi",
  description: "Envía diferentes archivos EHI desde URLs específicas.",
  alias: ["ehi"],
  use: "/ehi <claro|movistar|entel|bitel|flash|wings>",

  run: async (socket, msg, args) => {
    // Definir las URLs de los archivos EHI
    const ehiUrls = {
      claro: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/servidores/claro.ehi",
      movistar: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/servidores/movistar.ehi",
      entel: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/servidores/entel.ehi",
      bitel: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/servidores/bitel.ehi",
      flash: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/servidores/flash.ehi",
      wings: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/servidores/wings.ehi",
    };

    // Verificar si se proporcionó el argumento correcto
    const command = args[0]?.toLowerCase();
    if (!command || !ehiUrls[command]) {
      // Enviar mensaje de error si el argumento no es válido
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "Uso incorrecto del comando. Usa /ehi <claro|movistar|entel|bitel|flash|wings>.",
      });
      return;
    }

    // Obtener la URL del archivo correspondiente
    const fileUrl = ehiUrls[command];

    try {
      // Enviar mensaje de "Descargando..."
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "Descargando archivo...",
      });

      // Descargar el archivo
      const response = await axios.get(fileUrl, {
        responseType: "stream",
      });

      // Enviar el archivo como documento
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        document: {
          stream: response.data,
        },
        fileName: `${command}.ehi`,
        mimetype: "application/octet-stream",
      });

      // Enviar mensaje de éxito
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "El archivo se ha enviado correctamente.",
      });
    } catch (error) {
      console.error(error);

      // Enviar mensaje de error
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "¡Ups! Ha ocurrido un error al enviar el archivo.",
      });
    }
  },
};
