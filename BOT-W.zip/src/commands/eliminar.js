import axios from "axios";
import { verificarRolUsuario, connection } from "../conexion.js";

export default {
  name: "del",
  description: "Elimina un usuario de la base de datos.",
  alias: ["eliminar"],
  use: "/del 'id' ",

  run: async (socket, msg, args) => {
    const id = args.join(" ");
    const sender = msg.messages[0]?.key?.remoteJid;

    // Verificar el rol del usuario
    verificarRolUsuario(sender, async (err, rol) => {
      if (err) {
        console.error(err);
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          {
            text: `*Error al verificar el rol del usuario.*`,
          },
          { quoted: msg.messages[0] }
        );
        return;
      }

      // Solo los usuarios con rol de administrador pueden eliminar usuarios
      if (rol !== "admin") {
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: "No tienes permiso para ejecutar este comando.",
        });
        return;
      }


      if (!id) {
        // Si no se proporciona un ID, mostrar todos los usuarios registrados
        connection.query("SELECT * FROM usuarios", (err, results) => {
          if (err) {
            console.error(err);
            socket.sendMessage(
              msg.messages[0]?.key?.remoteJid,
              {
                text: `*Error al obtener los usuarios registrados.*`,
              },
              { quoted: msg.messages[0] }
            );
            return;
          }

          // Construir un mensaje con la lista de usuarios
          let userList = "LISTA DE USUARIOS /del id\n";
          results.forEach((user) => {
            userList += `ID: ${user.id}, RemoteJid: ${user.remotejid}, Rol: ${user.rol}\n`;
          });

          // Enviar el mensaje con la lista de usuarios
          socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
            text: userList,
          });
        });

        return;
      }

      // Verificar si el usuario a eliminar existe en la base de datos
      connection.query(
        "SELECT * FROM usuarios WHERE id = ?",
        [id],
        (err, results) => {
          if (err) {
            console.error(err);
            socket.sendMessage(
              msg.messages[0]?.key?.remoteJid,
              {
                text: `*Error al verificar el usuario a eliminar.*`,
              },
              { quoted: msg.messages[0] }
            );
            return;
          }

          if (results.length === 0) {
            // El usuario a eliminar no existe en la base de datos
            socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
              text: `No se encontró ningún usuario con el ID ${id} en la base de datos.`,
            });
            return;
          }

          // Eliminar el usuario de la base de datos
          connection.query(
            "DELETE FROM usuarios WHERE id = ?",
            [id],
            (err, results) => {
              if (err) {
                console.error(err);
                socket.sendMessage(
                  msg.messages[0]?.key?.remoteJid,
                  {
                    text: `*Error al eliminar el usuario.*`,
                  },
                  { quoted: msg.messages[0] }
                );
                return;
              }

              // Usuario eliminado exitosamente
              socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
                text: `El usuario con ID ${id} ha sido eliminado exitosamente de la base de datos.`,
              });
            }
          );
        }
      );
    });
  },
};
