import axios from "axios";
import { verificarRolUsuario, connection } from "../conexion.js";


export default {
  name: "add",
  description: "Agrega un nuevo usuario a la base de datos.",
  alias: ["add"],
  use: "/add '51948415593@s.whatsapp.net' ",

  run: async (socket, msg, args) => {
    const add = args.join(" ");
    const sender = msg.messages[0]?.key?.remoteJid;

    // Verificar el rol del usuario
    verificarRolUsuario(sender, async (err, rol) => {
      if (err) {
        console.error(err);
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          {
            text: `*Error al verificar el rol del usuario.*`,
          },
          { quoted: msg.messages[0] }
        );
        return;
      }

      // Solo los usuarios con rol de administrador pueden agregar nuevos usuarios
      if (rol !== "admin") {
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: "No tienes permiso para ejecutar este comando.",
        });
        return;
      }

      if (!add) {
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `/add 51948415593@s.whatsapp.net`,
        });

        return;
      }

      // Verificar si el nuevo usuario ya existe en la base de datos
      connection.query(
        "SELECT * FROM usuarios WHERE remotejid = ?",
        [add],
        (err, results) => {
          if (err) {
            console.error(err);
            socket.sendMessage(
              msg.messages[0]?.key?.remoteJid,
              {
                text: `*Error al verificar el nuevo usuario.*`,
              },
              { quoted: msg.messages[0] }
            );
            return;
          }

          if (results.length > 0) {
            // El usuario ya existe en la base de datos
            socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
              text: `El usuario ${add} ya existe en la base de datos.`,
            });
            return;
          }

          // El usuario no existe, agregarlo a la base de datos
          connection.query(
            "INSERT INTO usuarios (remotejid, rol) VALUES (?, ?)",
            [add, "usuario"],
            (err, results) => {
              if (err) {
                console.error(err);
                socket.sendMessage(
                  msg.messages[0]?.key?.remoteJid,
                  {
                    text: `*Error al agregar el nuevo usuario.*`,
                  },
                  { quoted: msg.messages[0] }
                );
                return;
              }

              // Nuevo usuario agregado exitosamente
              socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
                text: `El usuario ${add} ha sido agregado exitosamente a la base de datos como usuario.`,
              });
            }
          );
        }
      );
    });
  },
};
