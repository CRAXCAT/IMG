import { GoogleGenerativeAI } from "@google/generative-ai";

export default {
  name: "messages.upsert",

  async load(msg, socket) {
    try {
      const message = msg.messages[0];

      // Ignorar mensajes del propio usuario y mensajes que no son de notificación
      if (message?.key.fromMe || msg.type !== "notify") return;

      const content =
        message.message?.extendedTextMessage?.text ||
        message.message?.ephemeralMessage?.message?.extendedTextMessage?.text ||
        message.message?.conversation ||
        message.message?.imageMessage?.caption ||
        message.message?.videoMessage?.caption;

      if (!content) return;

      // Lógica para mensajes con prefijo "/"
      if (content.startsWith("/")) {
        const args = content.slice(1).trim().split(" ");
        const commandName = args.shift()?.toLowerCase();
        const command = socket.commands.find(
          (c) =>
            c.name === commandName || (c.alias && c.alias.includes(commandName))
        );

        if (command) {
          command.run(socket, msg, args);
        }
        return;
      }

      // Lógica para mensajes sin prefijo "/"
      const API_KEY = "AIzaSyAp9ibjbmXfSOnxl4JhGcv6vO59PZE3GnY"; // Clave API directamente incluida
      const genAI = new GoogleGenerativeAI(API_KEY);

      async function run() {
        // Obtener el modelo generativo
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = content;

        try {
          const result = await model.generateContent(prompt);
          const response = await result.response;
          const resultText = await response.text();
          console.log(resultText);
          await socket.sendMessage(message.key.remoteJid, { text: resultText });
        } catch (error) {
          console.error("Error al generar contenido:", error.message);
          await socket.sendMessage(message.key.remoteJid, {
            text: "¡Error al generar contenido, inténtalo más tarde!",
          });
        }
      }

      await run();  // Asegúrate de esperar a que la función `run` termine

      console.log(`Mensaje recibido sin prefijo '/': ${content}`);
    } catch (error) {
      console.error("Error en messages.upsert:", error);
      const remoteJid = msg.messages[0]?.key?.remoteJid;
      if (remoteJid) {
        await socket.sendMessage(remoteJid, {
          text: "¡Ups! Algo salió mal, inténtalo de nuevo.",
        });
      }
    }
  },
};
