npm start
+51912544079

npm install @whiskeysockets/baileys@latest
npm update ytdl-core @distube/ytdl-core
npm install @distube/ytdl-core@latest
npm install dotenv
npm install openai


# BaileysWaBot

> Este es un bot sencillo para WhatsApp, creado con la librería @whiskeysockets/baileys. Ofrece una variedad de comandos simples pero útiles que facilitan diversas acciones en la plataforma.

### `Importar a Replit`

[![Run on Repl.it](https://replit.com/badge/github/W4LX/BaileysWaBot)](https://replit.com/github/W4LX/BaileysWaBot)

### `Redes sociales`

- [Únete a nuestro Discord](https://discord.com/invite/MTjf2AenZm)
- [Sígueme en Instagram](https://www.instagram.com/walx.craxker)
- [Sígueme en TikTok](https://www.tiktok.com/@walt.dev)

### `Mantén el bot activo 24/7`

- [OptikServers](https://my.optikservers.com/join/dpyaodx5fgtWzmZ6)
